# @mmp/shared-ui

Shared component library, Tailwind preset, and assets for MMP React apps.

## Install

```bash
npm i github:moneypenny-admin/mmp-shared-ui
```

For local development, use a file reference instead:

```bash
npm i file:../mmp-shared-ui
```

## Setup

### 1. Install peer dependencies

```bash
npm i -D tailwindcss postcss autoprefixer
```

### 2. Tailwind config

Create `tailwind.config.js`:

```js
import { mmpPreset } from '@mmp/shared-ui/preset'

export default {
  presets: [mmpPreset],
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    './node_modules/@mmp/shared-ui/dist/**/*.js',
  ],
}
```

Create `postcss.config.js`:

```js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

### 3. Import CSS

In your **JavaScript entry point** (e.g. `main.tsx` or `index.tsx`), import the font CSS **before** your app CSS:

```ts
import '@mmp/shared-ui/styles/base.css'  // @font-face for Soehne & Tobias
import './index.css'                      // your Tailwind directives
```

Your `index.css` should contain:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

> **Important:** Import `base.css` from JavaScript, not via CSS `@import`. Vite only rebases relative `url()` paths (font files) correctly when the CSS is imported from JS.

### 4. Favicons

Copy the favicon files to your app's `public/` directory:

```bash
cp node_modules/@mmp/shared-ui/dist/assets/favicons/*.png public/assets/
```

Then add to your `index.html`:

```html
<link rel="icon" href="/assets/cropped-madame-moneypenny-logo-2024-site-icon-1-32x32.png" sizes="32x32" />
<link rel="icon" href="/assets/cropped-madame-moneypenny-logo-2024-site-icon-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="/assets/cropped-madame-moneypenny-logo-2024-site-icon-1-180x180.png" />
<meta name="msapplication-TileImage" content="/assets/cropped-madame-moneypenny-logo-2024-site-icon-1-270x270.png" />
```

### 5. Use components

```tsx
import { Footer, Header, Button, MmpLogo } from '@mmp/shared-ui'
```

## Components

### UI Components

| Component     | Props |
|---------------|-------|
| `Header`      | `title?`, `description?`, `variant?: 'gradient' \| 'solid' \| 'minimal'` |
| `Footer`      | `extraLinks?: {name, url}[]`, `disclaimer?: ReactNode` |
| `Button`      | `variant?: 'primary' \| 'secondary' \| 'outline' \| 'ghost' \| 'danger'`, extends `ButtonHTMLAttributes` |
| `Slider`      | `label`, `valueLabel`, `info?`, extends `InputHTMLAttributes` |
| `InfoCard`    | `title`, `icon`, `colorScheme: 'blue' \| 'green' \| 'yellow' \| 'indigo'`, `children` |
| `Spinner`     | `size?: 'sm' \| 'md' \| 'lg'` |
| `TooltipInfo` | `text` (optional `lucide-react` peer dep) |
| `Label`       | `variant?: 'fill' \| 'outline'`, `children` |
| `Badge`       | `variant?: 'apricot' \| 'ultraviolet'`, `rotate?: 'left' \| 'right'`, `children` |
| `Card`        | `variant?: 'default' \| 'outline-left' \| 'outline-top'`, `children` |

### Layout Components

| Component            | Props |
|----------------------|-------|
| `HeroSection`        | `tagline?`, `title`, `description?`, `bullets?`, `ctaLabel?`, `onCtaClick?`, `ctaHref?`, `secondaryText?`, `media`, `mediaPosition?: 'left' \| 'right'` |
| `SectionIntro`       | `tagline?`, `title`, `description?` |
| `TwoColumnText`      | `left`, `right`, `ctaLabel?`, `onCtaClick?`, `ctaHref?` |
| `FullSizeImageCopy`  | `tagline?`, `title`, `description?`, `listLabel?`, `bullets?`, `ctaLabel?`, `secondaryText?`, `image`, `imagePosition?: 'left' \| 'right'` |
| `FullSizeImageCards` | `tagline?`, `title`, `description?`, `cards: {title, description, ctaLabel?}[]`, `image`, `imagePosition?: 'left' \| 'right'` |
| `Quote`              | `tagline?`, `text`, `author?` |
| `TopicOverview`      | `tagline?`, `title`, `description?`, `topics: {title, description}[]` |
| `Accordion`          | `items: {title, content}[]`, `allowMultiple?`, `defaultOpen?` |
| `ListBorderTop`      | `tagline?`, `title`, `description?`, `items: {title, description, ctaLabel?}[]` |

### Icons

All icons accept `size?` and `className?` props and use `currentColor`.

```tsx
import { Check, Cross, Close, ArrowDown, ArrowUp } from '@mmp/shared-ui'
```

### Assets

```tsx
import { MmpLogo } from '@mmp/shared-ui'  // SVG path string
```

## Tailwind Preset Colors

All colors are namespaced under `mmp-*`:

| Token | Color | Hex |
|-------|-------|-----|
| `mmp-ultraviolet` | Primary | `#6100FF` |
| `mmp-ultraviolet-dark` | Primary hover | `#5100D6` |
| `mmp-lavendel` | Accent | `#AEB4F4` |
| `mmp-zitrone` | Highlight | `#FEFFBD` |
| `mmp-apricot` | Secondary | `#FFC163` |
| `mmp-creme` | Background | `#FFF6EE` |
| `mmp-bordeaux` | Dark text | `#3F061A` |
| `mmp-bordeaux-light` | Soft text | `#a5526a` |
| `mmp-eisblau` | Surface | `#EFF1FF` |
| `mmp-rauchblau` | Muted | `#585D94` |

Usage: `bg-mmp-ultraviolet`, `text-mmp-bordeaux`, `border-mmp-lavendel`, etc.

## Deployment

For private GitHub dependency on Netlify/Vercel, set `GITHUB_TOKEN` as an environment variable. The `prepare` script runs `npm run build` automatically on install.
